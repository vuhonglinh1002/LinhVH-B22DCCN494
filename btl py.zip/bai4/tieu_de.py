
# Tạo tiêu đề CSV từ tất cả các thuộc tính của Player
header = [
    'Player', 'From', 'To', 'Price'
]
